<template>
  <div id="app">
    <header>
      <nav>
        <ul>
          <li><router-link to="/">Home</router-link></li>
          <li><router-link to="/login" v-if="!isAuthenticated">Login</router-link></li>
          <li><router-link to="/dashboard" v-if="isAuthenticated">Dashboard</router-link></li>
          <li><button v-if="isAuthenticated" @click="logout">Logout</button></li>
        </ul>
      </nav>
    </header>

    <!-- 路由视图区域，动态显示页面 -->
    <router-view></router-view>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'

const isAuthenticated = ref(false) // 用来判断用户是否已经登录
const router = useRouter()

// 检查用户是否已登录（是否存在 Token）
const checkAuth = () => {
  const token = localStorage.getItem('token')
  if (token) {
    isAuthenticated.value = true
  } else {
    isAuthenticated.value = false
  }
}

// 退出登录，清除 Token 并跳转到登录页
const logout = () => {
  localStorage.removeItem('token')  // 移除 Token
  isAuthenticated.value = false
  router.push('/login')  // 跳转到登录页面
}

onMounted(() => {
  checkAuth() // 页面加载时检查登录状态
})
</script>

<style scoped>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  text-align: center;
  color: #2c3e50;
}

nav {
  margin: 20px 0;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin-right: 15px;
}

a {
  text-decoration: none;
  color: #42b983;
}

button {
  padding: 5px 10px;
  cursor: pointer;
  background-color: #42b983;
  color: white;
  border: none;
  border-radius: 4px;
}

button:hover {
  background-color: #36a572;
}
</style>
