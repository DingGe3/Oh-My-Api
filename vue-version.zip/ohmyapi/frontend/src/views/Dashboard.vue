<template>
  <div>
    <h1 style="text-align: center">Oh My Api</h1>
    <h4 style="text-align: center">点击下方查看内容</h4>

    <div class="nav">
      <ul class="navlist">
        <li class="btli">
          <a href="#">关于我们</a>
          <ul class="droplist">
            <li><a href="#" @click.prevent="showContent('xiangdao')">项导文档</a></li>
            <li><a href="#" @click.prevent="showContent('shiyong')">使用API</a></li>
          </ul>
        </li>
        <li class="btli">
          <a href="#">使用统计</a>
          <ul class="droplist">
            <li><a href="#" @click.prevent="showContent('chart')">本月统计</a></li>
            <li><a href="#" @click.prevent="showContent('demo1')">往月统计</a></li>
            <li><a href="#" @click.prevent="showContent('ip1')">IP日统计</a></li>
            <li><a href="#" @click.prevent="showContent('ip2')">ip月统计</a></li>
            <li><a href="#" @click.prevent="showContent('deepseek')">ds统计</a></li>
          </ul>
        </li>
        <li class="btli"><a href="#">导航项</a></li>
      </ul>
    </div>

    <div v-show="activeId === 'xiangdao'">
      <h1>点此进入项导文档</h1>
      <button @click="goTo('https://docs.pguide.studio/')">项导文档</button>
    </div>

    <div v-show="activeId === 'shiyong'">
      <h1>在此使用Api</h1>
      <button @click="goTo('https://docs.pguide.studio/public-service/GPT/')">
        GPT API公用调用网站及应用部署集合
      </button>
    </div>

    <div :id="id" v-for="id in chartIds" :key="id" class="chart" v-show="activeId === id" :style="chartStyle"></div>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick } from 'vue';
import * as echarts from 'echarts';

const activeId = ref('');
const chartIds = ['chart', 'deepseek', 'demo1', 'ip1', 'ip2'];
const chartStyle = 'width: 1200px; height: 600px; margin-left: 150px;';

function goTo(url) {
  window.location.assign(url);
}

function showContent(id) {
  activeId.value = id;
  nextTick(() => {
    if (chartIds.includes(id)) {
      renderChart(id);
    }
  });
}

async function renderChart(id) {
  let fileMap = {
    chart: 'apiperday.json',
    deepseek: 'deepseekday.json',
    demo1: 'apipermonth.json',
    ip1: 'ipperday.json',
    ip2: 'ippermonth.json',
  };
  const url = `./data_processed/${fileMap[id]}`;
  const res = await fetch(url);
  const data = await res.json();
  const chart = echarts.init(document.getElementById(id));
  chart.setOption(generateOption(id, data));
}

function formatDate(rawDate) {
  const d = new Date(rawDate);
  return `${d.getMonth() + 1}-${d.getDate()}`;
}

function generateOption(id, data) {
  const dates = data.map(d => formatDate(d['时间'] || d['月份']));
  const keys = Object.keys(data[0]).filter(k => k !== '时间' && k !== '月份');
  const series = keys.map(name => ({ name, type: 'line', data: data.map(d => d[name]) }));

  return {
    title: {
      text: {
        chart: '三月日访问量',
        deepseek: '四月ds日访问量',
        demo1: '往月访问量',
        ip1: '三月访问记录',
        ip2: '往月访问记录',
      }[id],
      textStyle: { color: 'rgb(255, 0, 0)', fontWeight: 'bold', fontSize: 20 },
    },
    tooltip: { trigger: 'axis' },
    legend: { data: keys, top: '5%' },
    grid: { top: '20%', left: '10%', right: '10%', bottom: '15%' },
    xAxis: { type: 'category', data: dates },
    yAxis: { type: 'value' },
    series,
  };
}
</script>

<style scoped>
.nav {
  height: 40px;
  background: #333;
  box-shadow: 0 1px 2px #666;
  z-index: 1000;
}
* {
  margin: 0;
  padding: 0;
  text-decoration: none;
  list-style: none;
}
.btli {
  float: left;
  width: 100px;
  line-height: 40px;
  text-align: center;
  position: relative;
}
.navlist a {
  color: #fff;
  display: block;
}
.navlist a:hover {
  background-color: #666;
}
.droplist {
  position: absolute;
  background: #333;
  box-shadow: 0 1px 2px #333;
  display: none;
  z-index: 1001;
}
.btli:hover .droplist {
  display: block;
}
.droplist li {
  border-top: 1px solid #666;
}
</style>
